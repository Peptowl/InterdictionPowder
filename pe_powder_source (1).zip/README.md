# ProjectE: Interdiction Powder (Forge 1.20.1 / 47.3.0)

Needs ProjectE 1.0.1 installed.

## Easiest: get the jar from GitHub (nothing to install)
1. Create a free GitHub account and a new empty repository.
2. Upload everything from this zip (including the hidden `.github` folder) to the repo.
3. Open the repo's **Actions** tab, wait for "Build mod jar" to finish (a few minutes).
4. Open the finished run, download the `pe_powder-jar` artifact, unzip it, and put the `.jar` in your `mods` folder next to ProjectE.

## Or build locally
1. Install JDK 17.
2. Easiest: download the Forge 1.20.1-47.3.0 MDK from files.minecraftforge.net and copy its `gradlew`, `gradlew.bat` and `gradle/` folder next to this project's `build.gradle`.
   (If our `build.gradle` errors, use the MDK's build.gradle and add only the ProjectE `runtimeOnly` line from ours.)
3. Put `ProjectE-1_20_1-PE1_0_1.jar` in `libs/`.
4. `./gradlew build` -> `build/libs/pe_powder-1.0.0.jar`. Drop it in `mods/` next to ProjectE. Test in-dev with `./gradlew runClient`.

## Use
Craft one Low + one Medium + one High Covalence Dust (shapeless) -> 6 Interdiction Powder.
Place on the ground like redstone dust. Any redstone signal touching a tile powers it (lever, torch, dust...); power spreads through connected powder up to 15 tiles.
While powered it glows and repels hostile mobs and flying projectiles using the same rules as the Interdiction Torch (respects ProjectE's `blacklist/interdiction` tag).

Config (`serverconfig/pe_powder-server.toml`): repelRadius (default 5; torch = 8), strength, hostileOnly, blockExplosions, explosionRadius.

NOTE: the real Interdiction Torch does NOT stop explosions. `blockExplosions` is an extra: it cancels explosions that start within explosionRadius of a lit powder tile.
