package dev.pepowder;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(InterdictionPowderMod.MODID)
public class InterdictionPowderMod {
	public static final String MODID = "pe_powder";

	public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
	public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
	public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MODID);

	public static final RegistryObject<Block> POWDER = BLOCKS.register("interdiction_powder", () -> new InterdictionPowderBlock(
			BlockBehaviour.Properties.of()
					.mapColor(MapColor.COLOR_CYAN)
					.noCollission()
					.instabreak()
					.sound(SoundType.STONE)
					.pushReaction(PushReaction.DESTROY)
					.lightLevel(state -> state.getValue(InterdictionPowderBlock.POWER) > 0 ? 7 : 0)));

	public static final RegistryObject<Item> POWDER_ITEM = ITEMS.register("interdiction_powder",
			() -> new ItemNameBlockItem(POWDER.get(), new Item.Properties()));

	public static final RegistryObject<BlockEntityType<InterdictionPowderBlockEntity>> POWDER_BE = BLOCK_ENTITIES.register("interdiction_powder",
			() -> BlockEntityType.Builder.of(InterdictionPowderBlockEntity::new, POWDER.get()).build(null));

	public InterdictionPowderMod() {
		IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
		BLOCKS.register(bus);
		ITEMS.register(bus);
		BLOCK_ENTITIES.register(bus);
		bus.addListener(this::addToCreativeTab);
		ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, PowderConfig.SPEC);
	}

	private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
		if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			event.accept(POWDER_ITEM);
		}
	}
}
