package dev.pepowder;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class InterdictionPowderBlockEntity extends BlockEntity {
	public InterdictionPowderBlockEntity(BlockPos pos, BlockState state) {
		super(InterdictionPowderMod.POWDER_BE.get(), pos, state);
	}

	// Runs on both sides (like ProjectE's torch) so deflected projectiles render smoothly.
	public static void tick(Level level, BlockPos pos, BlockState state, InterdictionPowderBlockEntity be) {
		if (state.getValue(InterdictionPowderBlock.POWER) == 0 || !PowderConfig.SPEC.isLoaded()) {
			return;
		}
		// Stagger tiles so a long line of powder doesn't all query on the same tick.
		if (Math.floorMod(level.getGameTime() + pos.asLong(), RepelHelper.INTERVAL) != 0) {
			return;
		}
		RepelHelper.repel(level, pos);
	}
}
