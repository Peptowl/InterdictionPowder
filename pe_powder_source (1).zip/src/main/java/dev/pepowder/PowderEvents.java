package dev.pepowder;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = InterdictionPowderMod.MODID)
public class PowderEvents {

	/**
	 * Optional extra (the real Interdiction Torch does NOT do this): cancels any explosion that
	 * starts within explosionRadius blocks of a lit powder tile.
	 */
	@SubscribeEvent
	public static void onExplosionStart(ExplosionEvent.Start event) {
		Level level = event.getLevel();
		if (level.isClientSide || !PowderConfig.SPEC.isLoaded() || !PowderConfig.BLOCK_EXPLOSIONS.get()) {
			return;
		}
		int r = PowderConfig.EXPLOSION_RADIUS.get();
		Vec3 c = event.getExplosion().getPosition();
		BlockPos origin = BlockPos.containing(c);
		for (BlockPos p : BlockPos.betweenClosed(origin.offset(-r, -r, -r), origin.offset(r, r, r))) {
			if (p.distSqr(origin) > (double) (r * r) || !level.hasChunkAt(p)) {
				continue;
			}
			BlockState s = level.getBlockState(p);
			if (s.is(InterdictionPowderMod.POWDER.get()) && s.getValue(InterdictionPowderBlock.POWER) > 0) {
				event.setCanceled(true);
				return;
			}
		}
	}
}
