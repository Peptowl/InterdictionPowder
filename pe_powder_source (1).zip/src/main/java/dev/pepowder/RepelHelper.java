package dev.pepowder;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Same rules as ProjectE's Interdiction Torch (WorldHelper.repelEntitiesInterdiction). */
public final class RepelHelper {
	/** Ticks between pushes per entity. Force is scaled up to compensate. */
	public static final int INTERVAL = 2;

	// Reuse ProjectE's own blacklist so anything excluded from the torch is excluded here too.
	private static final TagKey<EntityType<?>> BLACKLIST =
			TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation("projecte", "blacklist/interdiction"));

	// Ensures an entity covered by many powder tiles is only pushed once per interval.
	private static final Map<Entity, Long> LAST_PUSH = new WeakHashMap<>();

	private RepelHelper() {
	}

	private static boolean valid(Entity entity, boolean hostileOnly) {
		if (entity.isSpectator() || entity.getType().is(BLACKLIST)) {
			return false;
		}
		if (entity instanceof Projectile) {
			return !entity.onGround();
		}
		if (!(entity instanceof Mob)) {
			return false;
		}
		return !hostileOnly || entity instanceof Enemy;
	}

	public static void repel(Level level, BlockPos pos) {
		boolean hostileOnly = PowderConfig.HOSTILE_ONLY.get();
		double radius = PowderConfig.RADIUS.get();
		double k = PowderConfig.STRENGTH.get() * INTERVAL / 1.5D;
		long bucket = level.getGameTime() / INTERVAL;
		Vec3 center = new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);

		for (Entity entity : level.getEntitiesOfClass(Entity.class, new AABB(pos).inflate(radius), e -> valid(e, hostileOnly))) {
			Long last = LAST_PUSH.get(entity);
			if (last != null && last.longValue() == bucket) {
				continue;
			}
			LAST_PUSH.put(entity, bucket);
			Vec3 away = entity.position().subtract(center);
			double distance = away.length() + 0.1D;
			entity.setDeltaMovement(entity.getDeltaMovement().add(away.scale(k / distance)));
		}
	}
}
