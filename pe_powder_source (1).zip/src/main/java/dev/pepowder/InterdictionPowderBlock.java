package dev.pepowder;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * A flat dust that lies on the ground like redstone. It connects to neighbouring powder,
 * lights up (soul-fire colours) when it receives redstone power, and repels mobs while lit.
 * Power spreads along connected powder (15 tiles from any source), decaying by 1 per tile.
 */
public class InterdictionPowderBlock extends Block implements EntityBlock {
	public static final BooleanProperty NORTH = BlockStateProperties.NORTH;
	public static final BooleanProperty EAST = BlockStateProperties.EAST;
	public static final BooleanProperty SOUTH = BlockStateProperties.SOUTH;
	public static final BooleanProperty WEST = BlockStateProperties.WEST;
	public static final IntegerProperty POWER = BlockStateProperties.POWER;

	private static final VoxelShape SHAPE = Block.box(0.0D, 0.0D, 0.0D, 16.0D, 1.0D, 16.0D);

	public InterdictionPowderBlock(Properties props) {
		super(props);
		registerDefaultState(stateDefinition.any()
				.setValue(NORTH, false).setValue(EAST, false)
				.setValue(SOUTH, false).setValue(WEST, false)
				.setValue(POWER, 0));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(NORTH, EAST, SOUTH, WEST, POWER);
	}

	private static BooleanProperty prop(Direction dir) {
		return switch (dir) {
			case NORTH -> NORTH;
			case EAST -> EAST;
			case SOUTH -> SOUTH;
			default -> WEST;
		};
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
		return SHAPE;
	}

	@Override
	public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
		BlockPos below = pos.below();
		BlockState belowState = level.getBlockState(below);
		return belowState.isFaceSturdy(level, below, Direction.UP) || belowState.is(Blocks.HOPPER);
	}

	@Nullable
	@Override
	public BlockState getStateForPlacement(BlockPlaceContext ctx) {
		Level level = ctx.getLevel();
		BlockPos pos = ctx.getClickedPos();
		BlockState state = defaultBlockState();
		for (Direction dir : Direction.Plane.HORIZONTAL) {
			state = state.setValue(prop(dir), level.getBlockState(pos.relative(dir)).is(this));
		}
		return state;
	}

	@Override
	public BlockState updateShape(BlockState state, Direction dir, BlockState neighborState, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
		if (dir.getAxis().isHorizontal()) {
			return state.setValue(prop(dir), neighborState.is(this));
		}
		return state;
	}

	@Override
	public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moving) {
		if (!level.isClientSide && !oldState.is(this)) {
			level.scheduleTick(pos, this, 1);
		}
	}

	@Override
	public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moving) {
		if (level.isClientSide) {
			return;
		}
		if (!state.canSurvive(level, pos)) {
			dropResources(state, level, pos);
			level.removeBlock(pos, false);
			return;
		}
		if (!level.getBlockTicks().hasScheduledTick(pos, this)) {
			level.scheduleTick(pos, this, 1);
		}
	}

	@Override
	public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		int target = computePower(level, pos);
		if (target != state.getValue(POWER)) {
			level.setBlock(pos, state.setValue(POWER, target), Block.UPDATE_ALL);
		}
	}

	private int computePower(Level level, BlockPos pos) {
		// Any redstone signal touching this tile counts as a full-strength source.
		int power = level.getBestNeighborSignal(pos) > 0 ? 15 : 0;
		for (Direction dir : Direction.Plane.HORIZONTAL) {
			BlockState neighbor = level.getBlockState(pos.relative(dir));
			if (neighbor.is(this)) {
				power = Math.max(power, neighbor.getValue(POWER) - 1);
			}
		}
		return Math.max(power, 0);
	}

	/** Lets redstone dust visually connect to / power into the powder from the sides. */
	@Override
	public boolean canConnectRedstone(BlockState state, BlockGetter level, BlockPos pos, @Nullable Direction direction) {
		return direction != null && direction.getAxis().isHorizontal();
	}

	@Override
	public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
		if (state.getValue(POWER) > 0 && random.nextInt(5) == 0) {
			level.addParticle(ParticleTypes.SOUL_FIRE_FLAME,
					pos.getX() + 0.2 + random.nextDouble() * 0.6, pos.getY() + 0.1, pos.getZ() + 0.2 + random.nextDouble() * 0.6,
					0.0D, 0.02D, 0.0D);
		}
	}

	@Nullable
	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new InterdictionPowderBlockEntity(pos, state);
	}

	@Nullable
	@Override
	@SuppressWarnings("unchecked")
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
		return type == InterdictionPowderMod.POWDER_BE.get()
				? (BlockEntityTicker<T>) (BlockEntityTicker<InterdictionPowderBlockEntity>) InterdictionPowderBlockEntity::tick
				: null;
	}
}
