package dev.pepowder;

import net.minecraftforge.common.ForgeConfigSpec;

public class PowderConfig {
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.IntValue RADIUS;
	public static final ForgeConfigSpec.DoubleValue STRENGTH;
	public static final ForgeConfigSpec.BooleanValue HOSTILE_ONLY;
	public static final ForgeConfigSpec.BooleanValue BLOCK_EXPLOSIONS;
	public static final ForgeConfigSpec.IntValue EXPLOSION_RADIUS;

	static {
		ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
		RADIUS = b.comment("Repel range in blocks around EACH lit powder tile (Interdiction Torch uses 8). Lower this for long lines of powder to save performance.")
				.defineInRange("repelRadius", 5, 1, 16);
		STRENGTH = b.comment("Push strength multiplier. 1.0 matches the Interdiction Torch.")
				.defineInRange("strength", 1.0D, 0.0D, 10.0D);
		HOSTILE_ONLY = b.comment("If true, only hostile mobs and in-flight projectiles are repelled (same as ProjectE's default). If false, all non-blacklisted mobs are repelled.")
				.define("hostileOnly", true);
		BLOCK_EXPLOSIONS = b.comment("If true, explosions that start within explosionRadius of a lit powder tile are cancelled. NOTE: the real Interdiction Torch does not do this.")
				.define("blockExplosions", true);
		EXPLOSION_RADIUS = b.comment("Radius (blocks) around lit powder where explosions are cancelled.")
				.defineInRange("explosionRadius", 6, 1, 16);
		SPEC = b.build();
	}
}
